@extends('backend.layout')
@section('maincontent')
	@include('backend/part/dashboard')
@endsection()