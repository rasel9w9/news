<div class="col-md-12 col-sm-12 col-xs-12">			

	<div class="box_layout col-md-12 col-sm-12 col-xs-12">			

		<h3 class="no_padding"><i class="fa fa-info-circle"></i> About</h3>

	</div>
	
	<div class="box_layout col-md-12 col-sm-12 col-xs-12">			

		<h2>Mukto NMS (News Management System) Version 1.1.1 </h2>
		<hr>
		<h3>Credit</h3>
		<p>Mukto NMS is created by <a href="http://muktodharaltd.com/">Muktodhara Technology Limited</a>.</p>
		
		<h3>Terms & Conditions</h3>
		<p>
		1. Mukto NMS is not free and open source software.
		<br>
		2. You don't have any right to run the program, for any purpose.
		<br>
		3. You can not access to the source code, or study how the NMS works, and have no rights to change it to make it do what you wish.
		<br>
		4. You don't have any permission to make copies of the original NMS or give it to others or sell it.
		<br>
		5. You have no permission to modify any versions of this NMS.

		</p>
		
		<p>
		
		YOU MAY NOT MODIFY, COPY, REPRODUCE, REPUBLISH, UPLOAD, POST, TRANSMIT, OR DISTRIBUTE, IN ANY MANNER, THE CONTENT ON OUR WEBSITE, INCLUDING TEXT, GRAPHICS, CODE AND/OR SOFTWARE. 
		<br>
		<br>
		You will not, directly or indirectly: decompile or attempt to discover the source code or algorithms of the applications being provided on Mukto NMS including any Trials, Demos, Web Learning Sessions, or food data and/or databases related to the applications in order to copy, rent, resell, redistribute, lease, pledge, assign, or commercially exploit our services or any applications for the benefit of a third party; or remove any proprietary notices or labels. 
		<br>
		<br>
		You must retain all copyright and other proprietary notices contained in the original content on any copy you make of the content. You may not sell or modify the content or reproduce, display, publicly perform, distribute, or otherwise use the content in any way for any public or commercial purpose. The use of paid content on any other website or in a networked computer environment for any purpose is prohibited. If you violate any of the terms or conditions, your permission to use the content automatically terminates and you must immediately destroy any copies you have made of the content.
		
		</p>
		
		<br>
		
		<h4>&copy; copyright 2017-<?=date('Y');?> All Rights Reserved. <a href="http://muktodharaltd.com/">Muktodhara Technology Limited</a></h4>
	</div>
	
	
</div>