@extends('frontend.layout')
@section('maincontent')
	@include('frontend/part/single')
@endsection()