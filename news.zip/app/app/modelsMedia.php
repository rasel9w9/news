<?php

namespace App\app;

use Illuminate\Database\Eloquent\Model;

class modelsMedia extends Model
{
    //
}
