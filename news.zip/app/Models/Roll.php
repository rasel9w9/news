<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Roll extends Model
{
    //
	protected $table='rolls_table';
	protected $fillable = ['id','roll_name']; 
	
}
