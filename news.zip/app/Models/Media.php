<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Media extends Model
{
    //
	protected $table='media_table';
	protected $primaryKey = 'media_id';
}
